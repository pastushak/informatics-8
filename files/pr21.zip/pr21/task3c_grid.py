# ПР №21. Завдання 3в. grid()
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

window = Tk()
window.title("Розміщення з grid()")
window.geometry("300x200")

Label(window, text="Ім'я користувача:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
# TODO: поле в column=1
# TODO: мітка «Пароль:» і поле Entry(window, show="*") у row=1

window.mainloop()
