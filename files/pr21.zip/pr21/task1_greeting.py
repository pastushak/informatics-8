# ПР №21. Завдання 1. Вітання
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

name = input("Введіть своє ім'я: ")

window = Tk()
# TODO: заголовок «Вітання користувача», 400x100, фон lightblue

label = Label(window, text="")  # TODO: f"Привіт, {name}!", Arial 18, синій, фон lightblue
label.pack(pady=30)

window.mainloop()
