# ПР №21. Завдання 3б. place()
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

window = Tk()
window.title("Розміщення з place()")
window.geometry("400x200")
# TODO: мітка «Введіть свій вік» у (50, 80), Entry у (200, 80)

window.mainloop()
