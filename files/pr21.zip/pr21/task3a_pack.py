# ПР №21. Завдання 3а. pack()
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

window = Tk()
window.title("Розміщення з pack()")
window.geometry("400x100")
# TODO: мітка «Введіть своє ім'я:» і поле Entry, side=TOP

window.mainloop()
