# ПР №23. Завдання 1. Рівність випадкових чисел
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *
import random

num1 = num2 = 0

def generation():
    global num1, num2
    num1 = random.randint(1, 10)
    num2 = random.randint(1, 10)
    first.config(text=f"Перше число: {num1}")
    # TODO: друге число

def check():
    pass  # TODO: result.config(text=f"Результат: {num1 == num2}")

window = Tk()
window.title("Перевірка рівності")
window.geometry("300x200")
first = Label(window, text="Перше число: ?"); first.pack()
second = Label(window, text="Друге число: ?"); second.pack()
Button(window, text="Згенерувати", command=generation).pack(pady=3)
Button(window, text="Перевірити", command=check).pack(pady=3)
result = Label(window, text="Результат:"); result.pack()
window.mainloop()
