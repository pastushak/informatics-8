# ПР №23. Завдання 2. Чи перше більше?
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

def check1():
    num1 = float(entry1.get())
    num2 = float(entry2.get())
    res = False  # TODO
    result.config(text=f"Чи перше число більше? {res}")

window = Tk()
window.title("Порівняння чисел")
# TODO: два поля entry1, entry2, кнопка «Перевірити», мітка result

window.mainloop()
