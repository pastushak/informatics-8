# ПР №26. Завдання 3. Запит на вихід
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *
from tkinter import messagebox

def ask_exit():
    pass  # TODO: askyesno("Вихід", "Закрити програму?") → window.destroy()

window = Tk()
window.title("Вихід з програми")
Button(window, text="Вийти", command=ask_exit).pack(padx=40, pady=40)
window.mainloop()
