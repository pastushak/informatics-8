# ПР №26. Завдання 2. Перевірка віку
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *
from tkinter import messagebox

def check_age():
    try:
        age = int(entry.get())
    except ValueError:
        pass  # TODO: showwarning «Введіть число»
        return
    # TODO: менше 18 — showerror «Доступ заборонено», інакше showinfo «Ласкаво просимо!»

window = Tk()
window.title("Перевірка віку")
# TODO: мітка, поле entry, кнопка
window.mainloop()
