# ПР №26. Завдання 1. Види повідомлень
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *
from tkinter import messagebox

def show_info():
    messagebox.showinfo("Інформація", "Це інформаційне повідомлення!")

# TODO: show_warning(), show_error()

def ask_confirmation():
    response = messagebox.askyesno("Підтвердження", "Ви впевнені, що хочете продовжити?")
    # TODO: якщо так — текст кнопки «Продовжено» і фон #2ECC71, інакше «Скасовано» і #E74C3C

window = Tk()
window.title("Види повідомлень")
window.geometry("400x300")
Label(window, text="Оберіть тип повідомлення", font=("Arial", 14)).pack(pady=10)
Button(window, text="Info", font=("Arial", 12), bg="#2ECC71", fg="white", command=show_info).pack(pady=5)
# TODO: кнопки Warning (#F39C12), Error (#E74C3C), Confirm (#3498DB)
window.mainloop()
