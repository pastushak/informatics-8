# ПР №22. Завдання 4 (додатково). Час
# Прізвище та ім'я: ...
# Клас: 8-...

seconds = int(input("Кількість секунд: "))

hours = 0    # TODO: //
minutes = 0  # TODO: // і %
secs = 0     # TODO: %

print(f"{hours} год {minutes} хв {secs} с")
