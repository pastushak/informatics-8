# ПР №22. Завдання 2. Прямокутник
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *
import math

def perimeter():
    a = float(entry_a.get())
    b = float(entry_b.get())
    result.config(text=f"Периметр: {round(2 * (a + b), 2)}")

# TODO: функції area() і diagonal() (math.sqrt)

window = Tk()
window.title("Периметр і площа прямокутника")
window.geometry("400x400")

Label(window, text="Довжина:").pack()
entry_a = Entry(window); entry_a.pack()
Label(window, text="Ширина:").pack()
entry_b = Entry(window); entry_b.pack()

Button(window, text="Обчислити периметр", command=perimeter).pack(pady=3)
# TODO: кнопки «Обчислити площу» і «Обчислити діагональ»

result = Label(window, text="", font=("Arial", 14))
result.pack(pady=10)

window.mainloop()
