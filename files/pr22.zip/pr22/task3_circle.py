# ПР №22. Завдання 3. Коло
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *
import math

# TODO: функції length() — 2 * math.pi * r і area() — math.pi * r ** 2

window = Tk()
window.title("Коло")
# TODO: поле для радіуса, дві кнопки, мітка результату

window.mainloop()
