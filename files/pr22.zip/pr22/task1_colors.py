# ПР №22. Завдання 1. Зміна кольору фону
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

def change_to_red():
    window.configure(bg="red")
    window.title("Червоний")

# TODO: функції change_to_green() і change_to_blue()

window = Tk()
window.title("Зміна кольору фону")
window.geometry("400x300")

Button(window, text="Червоний", command=change_to_red, width=12).pack(pady=10)
# TODO: кнопки «Зелений» і «Синій»

window.mainloop()
