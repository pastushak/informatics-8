# Проєкт «Визначення індексу маси тіла (ІМТ)»
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *
from tkinter import messagebox


def calculate():
    """Обчислює ІМТ і визначає категорію."""
    # TODO: weight = float(...), height = float(...) / 100 — у метри
    # TODO: try / except ValueError, перевірка > 0
    # TODO: bmi = weight / height ** 2
    # TODO: if / elif / else: < 18.5 «дефіцит маси», < 25 «норма», < 30 «надлишкова вага», інакше «ожиріння»
    # TODO: result.config(text=..., bg=колір)
    # TODO: picture.config(image=images[category])
    pass


window = Tk()
window.title("Індекс маси тіла")
window.geometry("400x480")
window.resizable(False, False)

# Зображення — ПІСЛЯ створення вікна
images = {
    "дефіцит маси": PhotoImage(file="deficit.png"),
    "норма": PhotoImage(file="norma.png"),
    "надлишкова вага": PhotoImage(file="over.png"),
    "ожиріння": PhotoImage(file="obese.png"),
}

Label(window, text="Калькулятор ІМТ", font=("Arial", 18, "bold")).pack(pady=10)
# TODO: мітка і поле entry_weight («Вага, кг:»), мітка і поле entry_height («Зріст, см:»)
# TODO: кнопка «Визначити»
result = Label(window, text="", font=("Arial", 14), width=22, height=3)
result.pack()
picture = Label(window)
picture.pack(pady=10)

window.mainloop()
