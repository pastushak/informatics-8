# ПР №20. Завдання 4в
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

window = Tk()
# TODO: 450x350 зі зміщенням 200 і 100, «Вікно зі зміщенням», фон "turquoise"

window.mainloop()
