# ПР №20. Завдання 1. Про себе
# Прізвище та ім'я: ...
# Клас: 8-...

name = ""                 # TODO: str
age = 0                   # TODO: int
height = 0.0              # TODO: float, у метрах
loves_programming = True  # TODO: bool

print("Моє ім'я:", name)
# TODO: ще три рядки виведення
