# ПР №20. Завдання 4а
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

window = Tk()
# TODO: 400x300, заголовок «Базове вікно», фон "blue", без зміни розміру

window.mainloop()
