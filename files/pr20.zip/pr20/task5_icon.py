# ПР №20. Завдання 5 (додатково)
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

window = Tk()
window.title("Вікно з іконкою")
window.geometry("300x200")

icon = PhotoImage(file="myicon.png")
# TODO: встановіть іконку вікна

window.mainloop()
