# ПР №20. Завдання 4б
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

window = Tk()
# TODO: 500x500, «Обмеження розміру», фон HEX, minsize 300x300, maxsize 800x800

window.mainloop()
