# ПР №24. Завдання 1. Кислотність
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

def check_ph():
    ph = float(entry.get())
    if ph < 7:
        result.config(text="Кислий")
        window.configure(bg="tomato")
    # TODO: elif ph == 7 — «Нейтральний», lightgreen
    # TODO: else — «Лужний», lightblue

window = Tk()
window.title("Кислотність розчину")
window.geometry("300x170")
Label(window, text="Значення pH:").pack(pady=5)
entry = Entry(window); entry.pack()
Button(window, text="Перевірити", command=check_ph).pack(pady=5)
result = Label(window, text=""); result.pack()
window.mainloop()
