# ПР №24. Завдання 2. Розрахунок покупки
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

def calculate():
    product = entry_product.get()
    price = float(entry_price.get())
    money = float(entry_money.get())
    # TODO: якщо money >= price — «Ви купили ... Ваша решта: ... грн.»
    # TODO: інакше — «Не вистачає ... грн.»

window = Tk()
window.title("Розрахунок покупки")
# TODO: три мітки і поля entry_product, entry_price, entry_money, кнопка, мітка result

window.mainloop()
