# ПР №25. Завдання 3. НСД перебором
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

def calculate_gcd():
    a = int(entry_a.get())
    b = int(entry_b.get())
    gcd = 1
    # TODO: for i in range(1, min(a, b) + 1): якщо i ділить і a, і b — gcd = i
    result.config(text=f"НСД = {gcd}")

window = Tk()
window.title("Обчислення НСД (перебір)")
# TODO: поля entry_a, entry_b, кнопка, мітка result

window.mainloop()
