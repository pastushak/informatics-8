# ПР №25. Завдання 5 (додатково). Вгадай число
# Прізвище та ім'я: ...
# Клас: 8-...

import random

secret = random.randint(1, 100)
tries = 0
guess = 0
# TODO: while guess != secret: введення, tries += 1, підказки «більше» / «менше»
print("Вгадали за", tries, "спроб")
