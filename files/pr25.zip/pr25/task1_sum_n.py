# ПР №25. Завдання 1. Сума від 1 до N
# Прізвище та ім'я: ...
# Клас: 8-...

from tkinter import *

def calculate_sum():
    n = int(entry.get())
    s = 0
    # TODO: цикл for від 1 до n включно
    result.config(text=f"Сума чисел: {s}")

window = Tk()
window.title("Обчислення суми чисел")
window.geometry("300x150")
Label(window, text="Введіть число N:").pack()
entry = Entry(window); entry.pack()
Button(window, text="Обчислити", command=calculate_sum).pack(pady=5)
result = Label(window, text=""); result.pack()
window.mainloop()
